

class ExpiredToken(Exception):
    pass
